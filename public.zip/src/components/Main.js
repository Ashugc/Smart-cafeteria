import React from 'react';
import { Link } from 'react-router-dom';


const Card = (props) => {
    return (
        <div className='main-card'>
            {/* <img className='main-card-img' src={props.img} alt='user-avatar' />
            <h3>{props.userType}</h3> */}
            <button className='customer-login-button'>{props.userType}</button>
        </div>
    );
}

const Main = () => {
    return (
        <div className='main'>
            
            <h1 class="main-h1">Smart Cafeteria</h1>
            <br />
            <h3 class="main-h3">Please Make your Order By logging In!!</h3>
            <div className='main-card-container main-card-container-align'>
                <Link to="/customer/login"><Card userType="Customer page" /></Link>
          </div>
        </div>
    );
}

export default Main;