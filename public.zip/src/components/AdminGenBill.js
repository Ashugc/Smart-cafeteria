import React from 'react';
import PrintBill from './PrintBill';

const AdminGenBill = () => {
    return (
        <>
            <PrintBill />
        </>
    )
}

export default AdminGenBill;