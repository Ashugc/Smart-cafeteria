import React from 'react';

const CustomerPage = () => {
    return(
        <h1>Customer Page</h1>
    );
}

export default CustomerPage;